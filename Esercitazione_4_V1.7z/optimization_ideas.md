# spi_master.vhd
1. Instead of using two seperate registers, directly use spi_cmd from the std_discr_if
