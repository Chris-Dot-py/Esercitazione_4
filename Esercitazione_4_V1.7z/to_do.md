# things to do
1. Make std_discr_if as top level for spi master, std_discr_channels, and packet manager
